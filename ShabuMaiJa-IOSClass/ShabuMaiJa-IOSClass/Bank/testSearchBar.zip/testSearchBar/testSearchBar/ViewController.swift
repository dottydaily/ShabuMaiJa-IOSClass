//
//  ViewController.swift
//  SeacrBar
//
//  Created by iOS Dev on 13/11/2561 BE.
//  Copyright © 2561 iOS Dev. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tbView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    let store = ["Kuma","Indy"]
    var searchStore = [String]()
    var searching = false
    


}
extension ViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching{
            return searchStore.count
        }else{
           return store.count
        }
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if searching{
            cell?.textLabel?.text = searchStore[indexPath.row]
        }else{
            cell?.textLabel?.text = store[indexPath.row]
        }
        return cell!
    }
    
    
}
extension ViewController:UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar,textDidChange searchText: String){
        searchStore = store.filter({$0.lowercased().prefix(searchText.count) == searchText.lowercased()})
        searching = true
        tbView.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searching = false
        searchBar.text = ""
        tbView.reloadData()
    }
}

